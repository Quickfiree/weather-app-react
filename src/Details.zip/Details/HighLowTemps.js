const HighLowTemps = () => {
  return (
    <div>
        <table class = "highLow">
            <tr>
                <td>
                    H: 8<sup>&#176;C</sup>
                </td>
                <td>
                    L: 8<sup>&#176;C</sup>
                </td>
            </tr>
        </table>
    </div>
  )
}

export default HighLowTemps