import Cloud from './Vector.png'

const Status = () => {
  return (
    <div>
        
        <p id = "status"><img src = {Cloud} alt = "Null"/> The sky is </p>
    </div>
  )
}

export default Status